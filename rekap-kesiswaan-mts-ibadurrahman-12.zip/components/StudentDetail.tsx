
import React, { useMemo } from 'react';
import { StudentRecord } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { AlertTriangle, Award, CheckCircle, Clock, FileText, ArrowLeft, Download } from 'lucide-react';
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

interface Props {
  studentName: string;
  allRecords: StudentRecord[];
  onClose?: () => void; // Optional onClose prop
}

// Helper to convert image URL to data URI
const getDataUrl = (url: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.drawImage(img, 0, 0);
                resolve(canvas.toDataURL('image/jpeg'));
            } else {
                reject(new Error("Canvas context failed"));
            }
        };
        img.onerror = () => reject(new Error("Image load failed"));
        img.src = url;
    });
};

export const StudentDetail: React.FC<Props> = ({ studentName, allRecords, onClose }) => {
  const studentRecords = useMemo(() => 
    allRecords.filter(r => r.namaSiswa === studentName), 
  [studentName, allRecords]);

  const latestRecord = studentRecords[0]; 

  const stats = useMemo(() => {
    let violations = 0;
    let appreciations = 0;
    studentRecords.forEach(r => {
      const cat = r.kategori?.toLowerCase() || '';
      if (cat.includes('prestasi') || cat.includes('apresiasi')) {
        appreciations++;
      } else {
        violations++;
      }
    });
    return { violations, appreciations };
  }, [studentRecords]);

  const dataChart = [
    { name: 'Pelanggaran', value: stats.violations, color: '#ef4444' },
    { name: 'Prestasi', value: stats.appreciations, color: '#22c55e' },
  ].filter(d => d.value > 0);

  const handleDownloadPDF = async () => {
      const doc = new jsPDF();
      
      // Initial Y position
      let startY = 15;

      // Try to add Image
      if (latestRecord?.fotoSiswa) {
          try {
              const imgData = await getDataUrl(latestRecord.fotoSiswa);
              // Add image: x=14, y=15, w=25, h=25
              doc.addImage(imgData, 'JPEG', 14, 15, 25, 25);
              // Move text over
              doc.setFontSize(16);
              doc.text(`Detail Siswa: ${studentName}`, 45, 22);
              doc.setFontSize(10);
              doc.text(`Kelas: ${latestRecord?.kelas || '-'}`, 45, 28);
              doc.text(`Total Pelanggaran: ${stats.violations} | Total Prestasi: ${stats.appreciations}`, 45, 34);
              startY = 45; // Move table down
          } catch (e) {
              console.warn("Could not load image for PDF", e);
              // Fallback text only
              doc.setFontSize(16);
              doc.text(`Detail Siswa: ${studentName}`, 14, 15);
              doc.setFontSize(10);
              doc.text(`Kelas: ${latestRecord?.kelas || '-'}`, 14, 22);
              doc.text(`Total Pelanggaran: ${stats.violations} | Total Prestasi: ${stats.appreciations}`, 14, 28);
              startY = 35;
          }
      } else {
           doc.setFontSize(16);
           doc.text(`Detail Siswa: ${studentName}`, 14, 15);
           doc.setFontSize(10);
           doc.text(`Kelas: ${latestRecord?.kelas || '-'}`, 14, 22);
           doc.text(`Total Pelanggaran: ${stats.violations} | Total Prestasi: ${stats.appreciations}`, 14, 28);
           startY = 35;
      }
      
      autoTable(doc, {
          startY: startY,
          head: [['Tanggal', 'Kategori', 'Uraian', 'Status Tindakan', 'Catatan']],
          body: studentRecords.map(r => [
              r.tanggal,
              r.kategori,
              r.uraianKategori,
              r.statusTindakan ? 'Selesai' : 'Belum',
              r.catatanTindakan || '-'
          ]),
          headStyles: { fillColor: [34, 197, 94] }
      });
      
      doc.save(`detail_${studentName.replace(/\s+/g, '_')}.pdf`);
  };

  return (
    <div className="space-y-6">
      {/* Header with Navigation and Actions */}
      <div className="flex justify-between items-center border-b pb-3">
         <h2 className="text-xl font-bold text-gray-900">Detail Rekap</h2>
         <div className="flex gap-2">
             <button 
                onClick={handleDownloadPDF}
                className="flex items-center gap-2 px-3 py-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition text-sm font-medium shadow-sm"
             >
                <Download size={16} /> <span className="hidden sm:inline">PDF</span>
             </button>
             {onClose && (
                 <button 
                    onClick={onClose}
                    className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition text-sm font-medium"
                 >
                    <ArrowLeft size={16} /> Kembali
                 </button>
             )}
         </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6 items-start">
        <div className="w-full md:w-1/3 flex flex-col items-center">
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-primary-200 shadow-lg mb-3 bg-gray-100">
             {latestRecord?.fotoSiswa ? (
                <img src={latestRecord.fotoSiswa} alt={studentName} className="w-full h-full object-cover" />
             ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">No Image</div>
             )}
          </div>
          <h2 className="text-xl font-bold text-gray-900 text-center">{studentName}</h2>
          <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-medium mt-1">
            Kelas {latestRecord?.kelas}
          </span>
        </div>

        <div className="w-full md:w-2/3">
           <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-red-50 p-4 rounded-xl border border-red-100 flex flex-col items-center">
                 <AlertTriangle className="text-red-500 mb-2" />
                 <span className="text-2xl font-bold text-red-700">{stats.violations}</span>
                 <span className="text-xs text-red-600 uppercase font-semibold">Pelanggaran</span>
              </div>
              <div className="bg-green-50 p-4 rounded-xl border border-green-100 flex flex-col items-center">
                 <Award className="text-green-600 mb-2" />
                 <span className="text-2xl font-bold text-green-700">{stats.appreciations}</span>
                 <span className="text-xs text-green-600 uppercase font-semibold">Prestasi</span>
              </div>
           </div>

           {dataChart.length > 0 && (
             <div className="h-48 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={dataChart}
                     cx="50%"
                     cy="50%"
                     innerRadius={40}
                     outerRadius={70}
                     paddingAngle={5}
                     dataKey="value"
                   >
                     {dataChart.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={entry.color} />
                     ))}
                   </Pie>
                   <Tooltip />
                   <Legend />
                 </PieChart>
               </ResponsiveContainer>
             </div>
           )}
        </div>
      </div>

      <div className="border-t pt-4">
        <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <Clock size={18} /> Riwayat & Tindakan
        </h3>
        <div className="space-y-3 max-h-60 overflow-y-auto custom-scrollbar pr-2">
            {studentRecords.map((rec, idx) => {
                 const isPrestasi = rec.kategori.toLowerCase().includes('prestasi');
                 return (
                    <div key={idx} className={`p-3 rounded-lg border-l-4 ${isPrestasi ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
                        <div className="flex justify-between items-start">
                            <span className="text-xs font-mono text-gray-500">{rec.tanggal}</span>
                            <span className={`text-xs font-bold px-2 py-0.5 rounded ${isPrestasi ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                                {rec.kategori}
                            </span>
                        </div>
                        <p className="text-sm font-medium text-gray-800 mt-1">{rec.uraianKategori}</p>
                        
                        {/* Display Action Status */}
                        {isPrestasi ? (
                            rec.catatanTindakan ? (
                                <div className="mt-2 text-xs p-2 rounded bg-green-100 text-green-800 flex items-start gap-2 border border-green-200">
                                     <Award size={14} className="mt-0.5"/>
                                     <div>
                                         <strong className="block">Catatan Prestasi</strong>
                                         <div className="opacity-90">{rec.catatanTindakan}</div>
                                     </div>
                                </div>
                            ) : null
                        ) : (
                            <div className={`mt-2 text-xs p-2 rounded flex items-start gap-2 ${rec.statusTindakan ? 'bg-green-100 text-green-800' : 'bg-white/50 text-yellow-700 border border-yellow-200'}`}>
                                {rec.statusTindakan ? <CheckCircle size={14} className="mt-0.5"/> : <Clock size={14} className="mt-0.5"/>}
                                <div>
                                    <strong className="block">{rec.statusTindakan ? 'Sudah Ditangani' : 'Proses Penanganan'}</strong>
                                    {rec.catatanTindakan && <div className="mt-1 opacity-80">{rec.catatanTindakan}</div>}
                                </div>
                            </div>
                        )}
                    </div>
                 )
            })}
        </div>
      </div>
    </div>
  );
};
