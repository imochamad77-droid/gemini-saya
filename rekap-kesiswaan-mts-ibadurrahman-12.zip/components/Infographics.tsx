import React, { useMemo, useState } from 'react';
import { StudentRecord } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { Trophy, AlertTriangle, FileText, ChevronDown } from 'lucide-react';
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

interface Props {
  data: StudentRecord[];
}

export const Infographics: React.FC<Props> = ({ data }) => {
    const [filterClass, setFilterClass] = useState('');

    const filteredData = useMemo(() => 
        filterClass ? data.filter(d => d.kelas === filterClass) : data, 
    [data, filterClass]);

    const uniqueClasses = useMemo(() => Array.from(new Set(data.map(d => d.kelas))).sort(), [data]);

    const studentStats = useMemo(() => {
        const stats: Record<string, { name: string, class: string, violations: number, achievements: number }> = {};
        
        filteredData.forEach(r => {
            if (!stats[r.namaSiswa]) {
                stats[r.namaSiswa] = { name: r.namaSiswa, class: r.kelas, violations: 0, achievements: 0 };
            }
            
            const cat = r.kategori.toLowerCase();
            if (cat.includes('prestasi') || cat.includes('apresiasi')) {
                stats[r.namaSiswa].achievements++;
            } else {
                stats[r.namaSiswa].violations++;
            }
        });

        return Object.values(stats);
    }, [filteredData]);

    const topViolators = useMemo(() => 
        studentStats
            .filter(s => s.violations > 0)
            .sort((a, b) => b.violations - a.violations)
            .slice(0, 5),
    [studentStats]);

    const topAchievers = useMemo(() => 
        studentStats
            .filter(s => s.achievements > 0)
            .sort((a, b) => b.achievements - a.achievements)
            .slice(0, 5),
    [studentStats]);

    const handleDownloadPDF = () => {
        const doc = new jsPDF();
        doc.text("Laporan Infografis Kesiswaan", 14, 15);
        if(filterClass) doc.text(`Filter: Kelas ${filterClass}`, 14, 22);

        doc.text("Top 5 Pelanggaran", 14, 35);
        autoTable(doc, {
            startY: 40,
            head: [['No', 'Nama Siswa', 'Kelas', 'Jumlah Pelanggaran']],
            body: topViolators.map((s, i) => [i+1, s.name, s.class, s.violations]),
            theme: 'grid',
            headStyles: { fillColor: [220, 38, 38] }
        });

        // @ts-ignore
        const finalY = doc.lastAutoTable.finalY || 40;
        doc.text("Top 5 Prestasi", 14, finalY + 15);
        autoTable(doc, {
            startY: finalY + 20,
            head: [['No', 'Nama Siswa', 'Kelas', 'Jumlah Prestasi']],
            body: topAchievers.map((s, i) => [i+1, s.name, s.class, s.achievements]),
            theme: 'grid',
            headStyles: { fillColor: [22, 163, 74] }
        });

        doc.save("infografis_kesiswaan.pdf");
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row justify-between items-center bg-white p-6 rounded-2xl shadow-soft border border-slate-100 gap-4">
                <div>
                    <h2 className="text-2xl font-extrabold text-slate-800 tracking-tight">Infografis Kesiswaan</h2>
                    <p className="text-slate-500 text-sm font-medium">Visualisasi data prestasi dan pelanggaran siswa</p>
                </div>
                <div className="flex gap-3 w-full md:w-auto">
                    <div className="relative flex-grow md:flex-grow-0">
                        <select 
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 pr-10 appearance-none font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-400"
                            value={filterClass}
                            onChange={e => setFilterClass(e.target.value)}
                        >
                            <option value="">Semua Kelas</option>
                            {uniqueClasses.map(c => <option key={c} value={c}>Kelas {c}</option>)}
                        </select>
                        <ChevronDown className="absolute right-3 top-3 text-slate-400 pointer-events-none" size={16}/>
                    </div>
                    <button 
                        onClick={handleDownloadPDF}
                        className="flex items-center gap-2 bg-rose-600 text-white px-5 py-2.5 rounded-xl hover:bg-rose-700 transition shadow-lg shadow-rose-500/30 font-semibold"
                        title="Download PDF Laporan"
                    >
                        <FileText size={20} /> <span className="hidden sm:inline">Report</span>
                    </button>
                </div>
            </div>

            {/* Leaderboards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-2xl shadow-soft border border-slate-100 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-400 to-red-600"></div>
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2.5 bg-rose-50 rounded-xl text-rose-600">
                             <AlertTriangle size={24} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800">Top 5 Pelanggaran</h3>
                    </div>
                    <div className="space-y-4">
                        {topViolators.length === 0 ? (
                            <div className="text-slate-400 text-sm italic py-8 text-center bg-slate-50 rounded-xl">Belum ada data pelanggaran.</div>
                        ) : (
                            topViolators.map((s, idx) => (
                                <div key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl hover:shadow-md transition-shadow group-hover:border-rose-100">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-sm ${idx === 0 ? 'bg-yellow-400 text-white' : idx === 1 ? 'bg-slate-300 text-slate-600' : idx === 2 ? 'bg-orange-300 text-white' : 'bg-slate-100 text-slate-500'}`}>
                                            {idx + 1}
                                        </div>
                                        <div>
                                            <div className="font-bold text-slate-800 truncate max-w-[140px] sm:max-w-[200px]">{s.name}</div>
                                            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Kelas {s.class}</div>
                                        </div>
                                    </div>
                                    <span className="px-3 py-1 rounded-lg bg-rose-50 text-rose-700 font-bold border border-rose-100">{s.violations}</span>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-soft border border-slate-100 relative overflow-hidden group">
                     <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 to-green-600"></div>
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-600">
                             <Trophy size={24} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800">Top 5 Prestasi</h3>
                    </div>
                    <div className="space-y-4">
                        {topAchievers.length === 0 ? (
                            <div className="text-slate-400 text-sm italic py-8 text-center bg-slate-50 rounded-xl">Belum ada data prestasi.</div>
                        ) : (
                            topAchievers.map((s, idx) => (
                                <div key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl hover:shadow-md transition-shadow group-hover:border-emerald-100">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-sm ${idx === 0 ? 'bg-yellow-400 text-white' : idx === 1 ? 'bg-slate-300 text-slate-600' : idx === 2 ? 'bg-orange-300 text-white' : 'bg-slate-100 text-slate-500'}`}>
                                            {idx + 1}
                                        </div>
                                        <div>
                                            <div className="font-bold text-slate-800 truncate max-w-[140px] sm:max-w-[200px]">{s.name}</div>
                                            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Kelas {s.class}</div>
                                        </div>
                                    </div>
                                    <span className="px-3 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold border border-emerald-100">{s.achievements}</span>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            {/* Main Chart */}
            <div className="bg-white p-6 rounded-2xl shadow-soft border border-slate-100">
                <div className="mb-6">
                     <h3 className="text-lg font-bold text-slate-800">Statistik Aktivitas Siswa</h3>
                     <p className="text-slate-500 text-sm">Perbandingan jumlah pelanggaran dan prestasi (Top 15 Aktif)</p>
                </div>
                
                <div className="h-[500px] w-full bg-slate-50/50 rounded-xl border border-slate-100 p-4">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                            layout="vertical"
                            data={studentStats.filter(s => s.violations > 0 || s.achievements > 0).slice(0, 15)} 
                            margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                            barSize={20}
                        >
                            <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={true} stroke="#e2e8f0" />
                            <XAxis type="number" tick={{fontSize: 12, fill: '#64748b'}} axisLine={false} tickLine={false} />
                            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12, fill: '#475569', fontWeight: 600}} axisLine={false} tickLine={false} />
                            <Tooltip 
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                                cursor={{ fill: '#f1f5f9', opacity: 0.5 }}
                            />
                            <Legend wrapperStyle={{ paddingTop: '20px' }} iconType="circle"/>
                            <Bar dataKey="violations" name="Pelanggaran" fill="#ef4444" radius={[0, 4, 4, 0]} animationDuration={1000} />
                            <Bar dataKey="achievements" name="Prestasi" fill="#22c55e" radius={[0, 4, 4, 0]} animationDuration={1000} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};