import React, { useState, useMemo, useEffect } from 'react';
import { StudentRecord, FilterState, ADMIN_SHEET_URL } from '../types';
import { saveActionLocally, deleteRecordLocally, unhideRecordLocally, hideMultipleRecords, unhideMultipleRecords } from '../services/dataService';
import { Search, Filter, RefreshCw, RotateCcw, FileText, Download, Lock, CheckCircle, AlertCircle, Plus, Minus, User, Edit, Clock, Award, ChevronDown, Menu, Eye, EyeOff, ExternalLink, LogOut, Settings2, ListFilter, CheckSquare, Trash2, XCircle, Grid } from 'lucide-react';
import { Modal } from './Modal';
import { StudentDetail } from './StudentDetail';
import { AdminAuth } from './AdminAuth';
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

interface Props {
  data: StudentRecord[];
  onRefresh: () => void;
}

export const Dashboard: React.FC<Props> = ({ data, onRefresh }) => {
  const [filter, setFilter] = useState<FilterState>({
    startDate: '',
    endDate: '',
    searchName: '',
    kelas: '',
    kategori: ''
  });

  const [rowsPerPage, setRowsPerPage] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  
  // Auth & Modes
  const [hasAdminSession, setHasAdminSession] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Pending Actions
  const [pendingActionType, setPendingActionType] = useState<'OPEN_SHEET' | 'TOGGLE_SELECTION' | 'EDIT_ACTION' | null>(null);
  const [pendingRecord, setPendingRecord] = useState<StudentRecord | null>(null);
  
  const [editActionModalOpen, setEditActionModalOpen] = useState(false);
  const [currentActionData, setCurrentActionData] = useState<{id: string, status: boolean, note: string, type: 'PRESTASI' | 'PELANGGARAN'} | null>(null);

  const uniqueClasses = useMemo(() => Array.from(new Set(data.filter(d => !d.isHidden).map(d => d.kelas))).sort(), [data]);
  const uniqueCategories = useMemo(() => Array.from(new Set(data.filter(d => !d.isHidden).map(d => d.kategori))).sort(), [data]);
  const uniqueNames = useMemo(() => Array.from(new Set(data.filter(d => !d.isHidden).map(d => d.namaSiswa))).sort(), [data]);

  const filteredData = useMemo(() => {
    return data.filter(record => {
      if (!isSelectionMode && record.isHidden) return false;

      const matchesName = filter.searchName ? record.namaSiswa === filter.searchName : true;
      const matchesClass = filter.kelas ? record.kelas === filter.kelas : true;
      const matchesCategory = filter.kategori ? record.kategori === filter.kategori : true;
      
      let matchesDate = true;
      if (record.dateObj) {
         if (filter.startDate) {
            matchesDate = matchesDate && record.dateObj >= new Date(filter.startDate);
         }
         if (filter.endDate) {
            matchesDate = matchesDate && record.dateObj <= new Date(filter.endDate);
         }
      }

      return matchesName && matchesClass && matchesCategory && matchesDate;
    });
  }, [data, filter, isSelectionMode]);

  const stats = useMemo(() => {
    const sourceData = data.filter(d => !d.isHidden);
    let prestasi = 0;
    let pelanggaran = 0;
    sourceData.forEach(r => {
        if (r.kategori.toLowerCase().includes('prestasi')) prestasi++;
        else pelanggaran++;
    });
    return { total: sourceData.length, prestasi, pelanggaran };
  }, [data]);

  const paginatedData = useMemo(() => {
    if (rowsPerPage === -1) return filteredData;
    const start = (currentPage - 1) * rowsPerPage;
    return filteredData.slice(start, start + rowsPerPage);
  }, [filteredData, currentPage, rowsPerPage]);

  const totalPages = rowsPerPage === -1 ? 1 : Math.ceil(filteredData.length / rowsPerPage);

  // Handlers
  const handleReset = () => {
    setFilter({ startDate: '', endDate: '', searchName: '', kelas: '', kategori: '' });
    setCurrentPage(1);
    setSelectedIds(new Set());
  };

  const toggleExpand = (id: string) => {
    const newSet = new Set(expandedRows);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setExpandedRows(newSet);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newSelected = new Set(selectedIds);
      if (e.target.checked) {
          paginatedData.forEach(row => newSelected.add(row.id));
      } else {
          paginatedData.forEach(row => newSelected.delete(row.id));
      }
      setSelectedIds(newSelected);
  };

  const handleSelectRow = (id: string) => {
      const newSelected = new Set(selectedIds);
      if (newSelected.has(id)) newSelected.delete(id);
      else newSelected.add(id);
      setSelectedIds(newSelected);
  };

  const handleBulkHide = () => {
      if (selectedIds.size === 0) return;
      hideMultipleRecords(Array.from(selectedIds));
      setSelectedIds(new Set());
      onRefresh();
  };

  const handleBulkShow = () => {
      if (selectedIds.size === 0) return;
      unhideMultipleRecords(Array.from(selectedIds));
      setSelectedIds(new Set());
      onRefresh();
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text(`Rekap Data Kesiswaan`, 14, 15);
    doc.setFontSize(10);
    doc.text(`Total: ${stats.total} | Prestasi: ${stats.prestasi} | Pelanggaran: ${stats.pelanggaran}`, 14, 22);
    
    const exportData = filteredData.filter(d => !d.isHidden);

    autoTable(doc, {
        startY: 30,
        head: [['Tgl', 'Nama', 'Kelas', 'Kategori', 'Uraian', 'Status Tindakan']],
        body: exportData.map(row => [
            row.tanggal,
            row.namaSiswa,
            row.kelas,
            row.kategori,
            row.uraianKategori,
            row.statusTindakan ? `Sudah (${row.catatanTindakan || ''})` : 'Proses'
        ]),
        styles: { fontSize: 8 },
        headStyles: { fillColor: [34, 197, 94] }
    });

    doc.save(`rekap_kesiswaan.pdf`);
    setIsMenuOpen(false);
  };

  const handleDownloadCSV = () => {
    const exportData = filteredData.filter(d => !d.isHidden);
    const headers = ["Hari", "Tanggal", "Nama Siswa", "Kelas", "Kategori", "Uraian", "Keterangan", "Guru", "Status Tindakan", "Catatan Tindakan"];
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n"
      + exportData.map(e => [
          e.hari, e.tanggal, `"${e.namaSiswa}"`, e.kelas, e.kategori, `"${e.uraianKategori}"`, `"${e.keterangan}"`, `"${e.namaGuru}"`,
          e.statusTindakan ? "Sudah Ditangani" : "Proses", `"${e.catatanTindakan || ''}"`
        ].join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `rekap_kesiswaan.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setIsMenuOpen(false);
  };

  const handleAdminSheetClick = () => {
      if (hasAdminSession) {
          window.open(ADMIN_SHEET_URL, '_blank');
      } else {
          setPendingActionType('OPEN_SHEET');
          setAuthModalOpen(true);
      }
  };

  const handleSelectionModeClick = () => {
      if (hasAdminSession) {
          setIsSelectionMode(!isSelectionMode);
          setSelectedIds(new Set());
      } else {
          setPendingActionType('TOGGLE_SELECTION');
          setAuthModalOpen(true);
      }
  };

  const handleAdminAuthSuccess = () => {
      setHasAdminSession(true);
      setAuthModalOpen(false);

      if (pendingActionType === 'OPEN_SHEET') {
          window.open(ADMIN_SHEET_URL, '_blank');
      } else if (pendingActionType === 'TOGGLE_SELECTION') {
          setIsSelectionMode(true);
      } else if (pendingActionType === 'EDIT_ACTION' && pendingRecord) {
         const isPrestasi = pendingRecord.kategori.toLowerCase().includes('prestasi');
         setCurrentActionData({
             id: pendingRecord.id,
             status: pendingRecord.statusTindakan || false,
             note: pendingRecord.catatanTindakan || '',
             type: isPrestasi ? 'PRESTASI' : 'PELANGGARAN'
         });
         setEditActionModalOpen(true);
         setPendingRecord(null);
      }
      setPendingActionType(null);
  };

  const toggleRecordVisibility = (record: StudentRecord) => {
      if (!hasAdminSession) return;
      if (record.isHidden) unhideRecordLocally(record.id);
      else deleteRecordLocally(record.id);
      onRefresh(); 
  };

  const openEditAction = (record: StudentRecord) => {
      if (!hasAdminSession) {
          setPendingRecord(record);
          setPendingActionType('EDIT_ACTION');
          setAuthModalOpen(true);
          return;
      }
      const isPrestasi = record.kategori.toLowerCase().includes('prestasi');
      setCurrentActionData({
          id: record.id,
          status: record.statusTindakan || false,
          note: record.catatanTindakan || '',
          type: isPrestasi ? 'PRESTASI' : 'PELANGGARAN'
      });
      setEditActionModalOpen(true);
  };

  const saveAction = () => {
      if (!currentActionData) return;
      saveActionLocally(currentActionData.id, currentActionData.status, currentActionData.note);
      setEditActionModalOpen(false);
      onRefresh(); 
  };

  const isAllSelected = paginatedData.length > 0 && paginatedData.every(row => selectedIds.has(row.id));

  return (
    <div className="space-y-8">
      
      {/* Modern Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="group bg-white p-6 rounded-2xl shadow-soft hover:shadow-xl transition-all duration-300 border border-slate-100 hover:translate-y-[-4px]">
           <div className="flex justify-between items-start">
              <div>
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Total Catatan</p>
                 <h3 className="text-4xl font-extrabold text-slate-800">{stats.total}</h3>
              </div>
              <div className="p-3 rounded-2xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                 <Grid size={24} />
              </div>
           </div>
           <div className="mt-4 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 w-full"></div>
           </div>
        </div>

        <div className="group bg-white p-6 rounded-2xl shadow-soft hover:shadow-xl transition-all duration-300 border border-slate-100 hover:translate-y-[-4px]">
           <div className="flex justify-between items-start">
              <div>
                 <p className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-1">Total Prestasi</p>
                 <h3 className="text-4xl font-extrabold text-emerald-700">{stats.prestasi}</h3>
              </div>
              <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                 <Award size={24} />
              </div>
           </div>
           <div className="mt-4 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500" style={{ width: `${(stats.prestasi / Math.max(stats.total, 1)) * 100}%` }}></div>
           </div>
        </div>

        <div className="group bg-white p-6 rounded-2xl shadow-soft hover:shadow-xl transition-all duration-300 border border-slate-100 hover:translate-y-[-4px]">
           <div className="flex justify-between items-start">
              <div>
                 <p className="text-xs font-bold text-rose-500 uppercase tracking-wider mb-1">Total Pelanggaran</p>
                 <h3 className="text-4xl font-extrabold text-rose-700">{stats.pelanggaran}</h3>
              </div>
              <div className="p-3 rounded-2xl bg-rose-50 text-rose-600 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                 <AlertCircle size={24} />
              </div>
           </div>
           <div className="mt-4 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500" style={{ width: `${(stats.pelanggaran / Math.max(stats.total, 1)) * 100}%` }}></div>
           </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="bg-white rounded-2xl shadow-soft border border-slate-100 p-5 space-y-5">
         <div className="flex flex-wrap gap-4 items-end">
            
            {/* Search Box */}
            <div className="flex-1 min-w-[240px]">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 block">Cari Siswa</label>
                <div className="relative flex gap-2">
                    <div className="relative w-full">
                        <select 
                            className="w-full pl-4 pr-10 py-2.5 bg-slate-50 hover:bg-slate-100 border-none rounded-xl text-slate-700 font-medium focus:ring-2 focus:ring-primary-400 focus:bg-white transition-all appearance-none cursor-pointer"
                            value={filter.searchName}
                            onChange={e => setFilter({...filter, searchName: e.target.value})}
                        >
                            <option value="">Semua Siswa</option>
                            {uniqueNames.map(name => (
                                <option key={name} value={name}>{name}</option>
                            ))}
                        </select>
                        <ChevronDown className="absolute right-3 top-3 text-slate-400 pointer-events-none" size={16}/>
                    </div>
                    
                    <button 
                        className="px-5 py-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 hover:shadow-lg hover:shadow-primary-500/30 transition-all active:scale-95 flex items-center gap-2 font-semibold"
                        onClick={() => {/* reinforced action */}}
                    >
                        <Search size={18} /> <span className="hidden sm:inline">Cari</span>
                    </button>
                </div>
            </div>
            
            {/* Date & Filters */}
            <div className="flex flex-wrap gap-3 w-full lg:w-auto">
                <div className="w-full sm:w-auto">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 block">Dari</label>
                    <input 
                        type="date" 
                        className="w-full px-3 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-primary-400"
                        value={filter.startDate}
                        onChange={e => setFilter({...filter, startDate: e.target.value})}
                    />
                </div>
                <div className="w-full sm:w-auto">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 block">Sampai</label>
                    <input 
                        type="date" 
                        className="w-full px-3 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-primary-400"
                        value={filter.endDate}
                        onChange={e => setFilter({...filter, endDate: e.target.value})}
                    />
                </div>
                <div className="w-1/2 sm:w-auto min-w-[100px]">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 block">Kelas</label>
                    <div className="relative">
                        <select 
                            className="w-full px-3 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-primary-400 appearance-none"
                            value={filter.kelas}
                            onChange={e => setFilter({...filter, kelas: e.target.value})}
                        >
                            <option value="">Semua</option>
                            {uniqueClasses.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                        <ChevronDown className="absolute right-2 top-3 text-slate-400 pointer-events-none" size={14}/>
                    </div>
                </div>
                <div className="w-1/2 sm:w-auto min-w-[120px]">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 block">Kategori</label>
                    <div className="relative">
                        <select 
                            className="w-full px-3 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-primary-400 appearance-none"
                            value={filter.kategori}
                            onChange={e => setFilter({...filter, kategori: e.target.value})}
                        >
                            <option value="">Semua</option>
                            {uniqueCategories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                         <ChevronDown className="absolute right-2 top-3 text-slate-400 pointer-events-none" size={14}/>
                    </div>
                </div>
            </div>

            {/* Actions Toolbar */}
            <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end ml-auto pt-2 md:pt-0">
                <button 
                    onClick={onRefresh}
                    className="p-2.5 text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
                    title="Refresh Data"
                >
                    <RefreshCw size={20} />
                </button>

                <button 
                    onClick={handleReset}
                    className="p-2.5 text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors"
                    title="Reset Filter"
                >
                    <RotateCcw size={20} />
                </button>

                {/* Seleksi Tampilan Toggle */}
                <button 
                    onClick={handleSelectionModeClick}
                    className={`flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-xl transition-all shadow-sm ${
                        isSelectionMode 
                        ? 'bg-purple-600 text-white shadow-purple-500/30 ring-2 ring-purple-600 ring-offset-1' 
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                    }`}
                >
                    <ListFilter size={18} /> 
                    <span className="hidden sm:inline">{isSelectionMode ? 'Selesai' : 'Seleksi'}</span>
                </button>
                
                {isSelectionMode && selectedIds.size > 0 && (
                    <div className="flex gap-2 animate-in zoom-in duration-200">
                        <button 
                            onClick={handleBulkHide}
                            className="flex items-center gap-1 px-3 py-2 text-sm font-bold bg-white text-rose-600 rounded-xl hover:bg-rose-50 border border-rose-200"
                        >
                            <EyeOff size={16} /> Hide ({selectedIds.size})
                        </button>
                        <button 
                            onClick={handleBulkShow}
                            className="flex items-center gap-1 px-3 py-2 text-sm font-bold bg-white text-emerald-600 rounded-xl hover:bg-emerald-50 border border-emerald-200"
                        >
                            <Eye size={16} /> Show ({selectedIds.size})
                        </button>
                    </div>
                )}

                <button 
                    onClick={handleAdminSheetClick}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl hover:bg-emerald-100 transition-colors"
                >
                    <ExternalLink size={18} /> <span className="hidden sm:inline">Sheet</span>
                </button>

                <div className="relative">
                    <button 
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                    >
                        Export <ChevronDown size={16} />
                    </button>
                    
                    {isMenuOpen && (
                        <>
                            <div className="fixed inset-0 z-10" onClick={() => setIsMenuOpen(false)}></div>
                            <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 z-20 py-1.5 overflow-hidden animate-in fade-in zoom-in duration-100">
                                <button 
                                    onClick={handleDownloadPDF}
                                    className="w-full text-left px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                                >
                                    <FileText size={16} className="text-rose-500" /> Download PDF
                                </button>
                                <button 
                                    onClick={handleDownloadCSV}
                                    className="w-full text-left px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                                >
                                    <Download size={16} className="text-emerald-500" /> Download CSV
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
         </div>
      </div>

      {/* Modern Table */}
      <div className={`bg-white rounded-2xl shadow-soft border border-slate-100 overflow-hidden transition-all duration-300 ${isSelectionMode ? 'ring-2 ring-purple-400 ring-offset-2' : ''}`}>
        {isSelectionMode && (
             <div className="bg-purple-600 text-white px-6 py-3 text-sm font-medium flex items-center gap-2 shadow-inner">
                 <Settings2 size={18} className="animate-spin-slow" /> Mode Seleksi Tampilan Aktif: Centang data yang ingin diubah statusnya.
             </div>
        )}
        <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-sm text-left border-collapse">
                <thead className="bg-emerald-100 text-emerald-800 font-bold uppercase text-xs tracking-wider border-b border-emerald-200">
                    <tr>
                        {isSelectionMode && (
                            <th className="px-6 py-4 w-12 text-center">
                                <input 
                                    type="checkbox" 
                                    className="w-4 h-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500 cursor-pointer"
                                    checked={isAllSelected}
                                    onChange={handleSelectAll}
                                />
                            </th>
                        )}
                        <th className="px-6 py-4 whitespace-nowrap">Waktu</th>
                        <th className="px-6 py-4">Nama Siswa</th>
                        <th className="px-6 py-4 text-center">Kelas</th>
                        <th className="px-6 py-4">Kategori</th>
                        <th className="px-6 py-4">Uraian / Keterangan</th>
                        <th className="px-6 py-4">Guru</th>
                        <th className="px-6 py-4 text-center">Foto</th>
                        <th className="px-6 py-4 text-center">Status & Aksi</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                    {paginatedData.length === 0 ? (
                        <tr>
                            <td colSpan={isSelectionMode ? 10 : 9} className="px-6 py-12 text-center text-slate-400 italic">
                                Data tidak ditemukan.
                            </td>
                        </tr>
                    ) : (
                        paginatedData.map((row) => (
                            <tr 
                                key={row.id} 
                                className={`group transition-all duration-200 ${
                                    isSelectionMode && selectedIds.has(row.id) ? 'bg-purple-50' : 
                                    row.isHidden 
                                    ? 'bg-slate-50/80 grayscale opacity-60' 
                                    : 'hover:bg-slate-50 hover:shadow-sm'
                                }`}
                                onClick={() => {
                                    if(isSelectionMode) handleSelectRow(row.id);
                                }}
                            >
                                {isSelectionMode && (
                                    <td className="px-6 py-4 text-center">
                                        <input 
                                            type="checkbox" 
                                            className="w-4 h-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500 cursor-pointer"
                                            checked={selectedIds.has(row.id)}
                                            onChange={() => handleSelectRow(row.id)}
                                            onClick={(e) => e.stopPropagation()}
                                        />
                                    </td>
                                )}
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex flex-col">
                                        <span className="font-bold text-slate-700">{row.hari}</span>
                                        <span className="text-xs text-slate-400 font-mono">{row.tanggal}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <button 
                                        onClick={(e) => {
                                            if (isSelectionMode) return;
                                            e.stopPropagation();
                                            setSelectedStudent(row.namaSiswa);
                                        }}
                                        className={`font-bold text-sm text-left transition-colors ${row.isHidden || isSelectionMode ? 'text-slate-600 cursor-default' : 'text-slate-700 group-hover:text-primary-600'}`}
                                        disabled={row.isHidden || isSelectionMode}
                                    >
                                        {row.namaSiswa}
                                    </button>
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200">
                                        {row.kelas}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${
                                        row.isHidden 
                                        ? 'bg-slate-200 text-slate-500 border-slate-300'
                                        : row.kategori.toLowerCase().includes('prestasi') 
                                            ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                                            : 'bg-rose-50 text-rose-700 border-rose-100'
                                    }`}>
                                        {row.kategori}
                                    </span>
                                </td>
                                <td className="px-6 py-4 min-w-[240px] max-w-xs">
                                    <div className="space-y-1">
                                        <div className="flex items-start gap-1">
                                            <p className={`text-sm text-slate-700 leading-relaxed ${expandedRows.has(row.id) ? '' : 'line-clamp-2'}`}>
                                                {row.uraianKategori}
                                            </p>
                                            {row.uraianKategori.length > 50 && (
                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        toggleExpand(row.id);
                                                    }} 
                                                    className="text-primary-500 hover:bg-primary-50 rounded p-0.5 shrink-0 transition-colors"
                                                >
                                                    {expandedRows.has(row.id) ? <Minus size={14}/> : <Plus size={14}/>}
                                                </button>
                                            )}
                                        </div>
                                        {row.keterangan && <p className="text-xs text-slate-400 italic">"{row.keterangan}"</p>}
                                    </div>
                                </td>
                                <td className="px-6 py-4 text-sm font-medium text-slate-600">{row.namaGuru}</td>
                                <td className="px-6 py-4">
                                    {row.fotoSiswa ? (
                                        <div 
                                            className={`relative w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-md mx-auto group-hover:scale-105 transition-transform duration-300 ${!row.isHidden && !isSelectionMode ? 'cursor-pointer hover:shadow-lg' : ''}`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (!row.isHidden && !isSelectionMode) setPreviewImage(row.fotoSiswa);
                                            }}
                                        >
                                            <img src={row.fotoSiswa} alt={row.namaSiswa} className={`w-full h-full object-cover ${row.isHidden ? 'grayscale opacity-70' : ''}`}/>
                                        </div>
                                    ) : (
                                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-300 mx-auto border border-slate-200">
                                            <User size={20} />
                                        </div>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <div className="flex items-center justify-center gap-2">
                                        {/* Status Button */}
                                        <button 
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (isSelectionMode) return;
                                                openEditAction(row);
                                            }}
                                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm active:scale-95 border ${
                                                isSelectionMode ? 'cursor-default opacity-80' : 'cursor-pointer'
                                            } ${
                                                row.isHidden
                                                ? 'bg-slate-100 text-slate-400 border-slate-200'
                                                : row.kategori.toLowerCase().includes('prestasi')
                                                    ? 'bg-blue-50 text-blue-600 border-blue-100 hover:bg-blue-100'
                                                    : row.statusTindakan 
                                                        ? 'bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100' 
                                                        : 'bg-amber-50 text-amber-600 border-amber-100 hover:bg-amber-100'
                                            }`}
                                            disabled={isSelectionMode}
                                        >
                                            {!hasAdminSession && !isSelectionMode && <Lock size={10} className="mr-0.5 opacity-50" />}
                                            {row.kategori.toLowerCase().includes('prestasi') ? (
                                                <><Award size={13}/> {row.catatanTindakan ? 'Dicatat' : 'Input'}</>
                                            ) : (
                                                row.statusTindakan ? <><CheckCircle size={13}/> Selesai</> : <><Clock size={13}/> Proses</>
                                            )}
                                        </button>

                                        {/* Single Toggle */}
                                        {isSelectionMode && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    toggleRecordVisibility(row);
                                                }}
                                                className={`p-2 rounded-full transition-all ${
                                                    row.isHidden 
                                                    ? 'bg-emerald-100 text-emerald-600 hover:bg-emerald-200 ring-2 ring-emerald-300' 
                                                    : 'bg-rose-50 text-rose-300 hover:bg-rose-100 hover:text-rose-500'
                                                }`}
                                            >
                                                {row.isHidden ? <Eye size={14} /> : <EyeOff size={14} />}
                                            </button>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
        
        {/* Modern Pagination */}
        <div className="bg-slate-50 border-t border-slate-200 p-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3 text-sm font-medium text-slate-500">
                <span>Tampilkan</span>
                <div className="relative">
                    <select 
                        value={rowsPerPage} 
                        onChange={(e) => {
                            setRowsPerPage(Number(e.target.value));
                            setCurrentPage(1);
                            setSelectedIds(new Set());
                        }}
                        className="bg-white border border-slate-300 rounded-lg pl-3 pr-8 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary-500 appearance-none shadow-sm cursor-pointer"
                    >
                        <option value={10}>10</option>
                        <option value={20}>20</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                        <option value={-1}>Semua</option>
                    </select>
                    <ChevronDown size={14} className="absolute right-2 top-2.5 pointer-events-none"/>
                </div>
                <span>baris</span>
            </div>

            <div className="flex items-center bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                <button 
                    onClick={() => {
                        setCurrentPage(p => Math.max(1, p - 1));
                        setSelectedIds(new Set());
                    }}
                    disabled={currentPage === 1}
                    className="px-4 py-2 hover:bg-slate-50 border-r border-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium text-slate-600"
                >
                    Prev
                </button>
                 <span className="px-4 py-2 text-sm font-bold text-slate-700 bg-slate-50/50">
                    {currentPage} / {totalPages}
                 </span>
                <button 
                    onClick={() => {
                        setCurrentPage(p => Math.min(totalPages, p + 1));
                        setSelectedIds(new Set());
                    }}
                    disabled={currentPage === totalPages}
                    className="px-4 py-2 hover:bg-slate-50 border-l border-slate-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium text-slate-600"
                >
                    Next
                </button>
            </div>
        </div>
      </div>

      {/* Modals */}
      <Modal isOpen={!!previewImage} onClose={() => setPreviewImage(null)} title="Foto Siswa">
        {previewImage && <img src={previewImage} alt="Preview" className="w-full h-auto rounded-xl shadow-lg" />}
      </Modal>

      <Modal isOpen={!!selectedStudent} onClose={() => setSelectedStudent(null)} title="Detail Siswa" maxWidth="max-w-4xl">
         {selectedStudent && <StudentDetail studentName={selectedStudent} allRecords={data} onClose={() => setSelectedStudent(null)} />}
      </Modal>

      <AdminAuth 
        isOpen={isAuthModalOpen} 
        onClose={() => {
            setAuthModalOpen(false);
            setPendingActionType(null);
        }} 
        onSuccess={handleAdminAuthSuccess}
        credentials={{user: 'admin', pass: 'admin123'}}
      />

      <Modal isOpen={editActionModalOpen} onClose={() => setEditActionModalOpen(false)} title="Update Status & Catatan">
          {currentActionData && (
              <div className="space-y-5">
                  <div className={`p-4 rounded-xl border flex items-center gap-3 ${currentActionData.type === 'PRESTASI' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
                      {currentActionData.type === 'PRESTASI' ? <Award size={24}/> : <AlertCircle size={24}/>}
                      <div>
                          <div className="text-xs uppercase font-bold opacity-70">Mode Edit</div>
                          <div className="font-bold text-lg">{currentActionData.type}</div>
                      </div>
                  </div>

                  {currentActionData.type === 'PELANGGARAN' && (
                    <div className="flex items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-sm">
                        <input 
                            type="checkbox" 
                            id="statusAction"
                            checked={currentActionData.status}
                            onChange={e => setCurrentActionData({...currentActionData, status: e.target.checked})}
                            className="w-6 h-6 text-primary-600 rounded-md focus:ring-primary-500 cursor-pointer"
                        />
                        <label htmlFor="statusAction" className="font-semibold text-slate-800 cursor-pointer select-none">
                            Tandai sebagai "Sudah Ditangani"
                        </label>
                    </div>
                  )}

                  <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">
                          {currentActionData.type === 'PRESTASI' ? 'Catatan Apresiasi / Hadiah' : 'Catatan Tindak Lanjut'}
                      </label>
                      <textarea 
                          className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:outline-none shadow-sm text-sm"
                          rows={4}
                          value={currentActionData.note}
                          onChange={e => setCurrentActionData({...currentActionData, note: e.target.value})}
                          placeholder={currentActionData.type === 'PRESTASI' ? "Contoh: Sertifikat diberikan, Hadiah buku..." : "Contoh: Pemanggilan orang tua, Konseling BK..."}
                      ></textarea>
                  </div>
                  <div className="flex justify-end gap-3 pt-2">
                      <button onClick={() => setEditActionModalOpen(false)} className="px-5 py-2.5 text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 font-medium transition-colors">Batal</button>
                      <button onClick={saveAction} className="px-5 py-2.5 text-white bg-primary-600 rounded-xl hover:bg-primary-700 shadow-lg shadow-primary-500/30 font-medium transition-colors">Simpan Perubahan</button>
                  </div>
              </div>
          )}
      </Modal>
    </div>
  );
};