
import React from 'react';
import { LOGO_URL } from '../types';

export const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 no-print px-4 py-4 pointer-events-none">
      <div className="pointer-events-auto max-w-7xl mx-auto">
        <div className="bg-emerald-100/95 backdrop-blur-xl border border-emerald-200 shadow-soft rounded-2xl p-3 pl-4 flex items-center justify-start gap-5 transition-all hover:shadow-lg hover:bg-emerald-200/90">
            
            {/* Logo Container 3D Effect */}
            <div className="relative group shrink-0">
                <div className="absolute inset-0 bg-green-500/20 rounded-full blur-md group-hover:blur-lg transition-all duration-300"></div>
                <div className="relative bg-gradient-to-br from-white to-green-50 rounded-full p-1.5 shadow-md border border-white">
                    <img 
                        src={LOGO_URL} 
                        alt="Logo MTs" 
                        className="w-10 h-10 md:w-12 md:h-12 object-contain rounded-full transform transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
                        style={{ filter: "drop-shadow(0 2px 3px rgba(0,0,0,0.1))" }}
                        onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://via.placeholder.com/50?text=Logo';
                        }}
                    />
                </div>
            </div>
            
            {/* Title */}
            <div className="flex flex-col justify-center">
                <h1 className="text-lg md:text-2xl font-extrabold text-emerald-950 tracking-tight leading-tight drop-shadow-sm">
                Rekap Catatan Kesiswaan
                </h1>
                <p className="text-xs md:text-sm font-bold text-emerald-800 tracking-wide uppercase">
                MTs. Ibadurrahman Malang
                </p>
            </div>
        </div>
      </div>
    </header>
  );
};
