import React, { useEffect, useState } from 'react';
import { AdminAuth } from './AdminAuth';
import { ArrowLeft, Lock } from 'lucide-react';

interface Props {
    onCancel: () => void;
}

export const AddRecord: React.FC<Props> = ({ onCancel }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(true);

    useEffect(() => {
        if (isAuthenticated) {
            // Load Tally script only when authenticated
            const scriptUrl = "https://tally.so/widgets/embed.js";
            if (!document.querySelector(`script[src="${scriptUrl}"]`)) {
                const script = document.createElement("script");
                script.src = scriptUrl;
                script.async = true;
                script.onload = () => {
                    // @ts-ignore
                    if (typeof Tally !== "undefined") Tally.loadEmbeds();
                };
                document.body.appendChild(script);
            } else {
                // @ts-ignore
                if (typeof Tally !== "undefined") Tally.loadEmbeds();
            }
        }
    }, [isAuthenticated]);

    const handleSuccess = () => {
        setIsAuthenticated(true);
        setIsAuthModalOpen(false);
    };

    if (!isAuthenticated) {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] gap-6 animate-in fade-in zoom-in duration-300">
                <div className="text-center text-slate-500">
                    <div className="mb-4 inline-flex p-5 bg-slate-100 rounded-full text-slate-400 shadow-sm border border-slate-200">
                        <Lock size={48} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-700">Akses Admin Diperlukan</h3>
                    <p className="max-w-xs mx-auto mt-2 text-sm">Halaman ini khusus untuk admin menambahkan catatan baru ke database.</p>
                </div>
                
                <button 
                    onClick={onCancel}
                    className="flex items-center gap-2 px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 hover:text-slate-900 font-bold transition-all shadow-sm active:scale-95"
                >
                    <ArrowLeft size={18} /> Kembali ke Dashboard
                </button>

                <AdminAuth 
                    isOpen={isAuthModalOpen} 
                    onClose={onCancel} // Close modal triggers cancel (back to dashboard)
                    onSuccess={handleSuccess}
                    credentials={{user: 'admin', pass: 'admin'}}
                />
            </div>
        );
    }

    return (
        <div className="space-y-4 animate-in fade-in duration-500">
            <div className="flex justify-between items-center mb-2">
                <button 
                    onClick={onCancel}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800 bg-white hover:bg-slate-50 rounded-lg border border-transparent hover:border-slate-200 transition-all"
                >
                    <ArrowLeft size={16} /> Kembali
                </button>
                <div className="px-3 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-full border border-green-100 flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    Admin Mode
                </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-soft overflow-hidden border border-slate-100 relative">
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-400 to-amber-500 z-10"></div>
                 <iframe 
                    data-tally-src="https://tally.so/embed/A7rJgo?alignLeft=1&hideTitle=1&transparentBackground=1&dynamicHeight=1" 
                    loading="lazy" 
                    width="100%" 
                    height="1069" 
                    frameBorder="0" 
                    title="Rekap Catatan Kesiswaan MTs. Ibadurrahman 1"
                    className="relative z-0"
                ></iframe>
            </div>
        </div>
    );
};