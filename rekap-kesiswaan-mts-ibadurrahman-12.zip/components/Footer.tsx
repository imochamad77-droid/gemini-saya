import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-primary-900 text-white py-6 mt-12 no-print">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm opacity-80">&copy; {new Date().getFullYear()} MTs. Ibadurrahman Malang. All rights reserved.</p>
        <p className="text-xs opacity-60 mt-1">Sistem Informasi Rekapitulasi Catatan Kesiswaan</p>
      </div>
    </footer>
  );
};