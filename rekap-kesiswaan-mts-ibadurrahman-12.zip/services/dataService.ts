
import { StudentRecord, DATA_URL } from '../types';

// Helper to parse CSV line respecting quotes
const parseCSVLine = (text: string) => {
  const re_value = /(?!\s*$)\s*(?:'([^']*)'|"([^"]*)"|([^,'"\s\\]*(?:\s+[^,'"\s\\]+)*))\s*(?:,|$)/g;
  const a = [];
  text.replace(re_value, (m0, m1, m2, m3) => {
    if (m1 !== undefined) a.push(m1.replace(/\\'/g, "'"));
    else if (m2 !== undefined) a.push(m2.replace(/\\"/g, '"'));
    else if (m3 !== undefined) a.push(m3);
    return '';
  });
  if (/,\s*$/.test(text)) a.push('');
  return a;
};

const parseDate = (dateStr: string): Date | null => {
  if (!dateStr) return null;
  // Try standard formats
  const parts = dateStr.split(/[-/]/);
  
  // Check if DD/MM/YYYY or MM/DD/YYYY
  // Google Sheets usually outputs based on locale. 
  // We'll try to guess based on standard Indonsian format DD/MM/YYYY first
  if (parts.length === 3) {
    const p1 = parseInt(parts[0]);
    const p2 = parseInt(parts[1]);
    const p3 = parseInt(parts[2]);

    // Assumption: Year is usually 4 digits (2024), Day/Month are 1-2.
    // If p3 is year
    if (p3 > 1000) {
       // DD/MM/YYYY
       const d = new Date(p3, p2 - 1, p1);
       if (!isNaN(d.getTime())) return d;
    } 
    // If p1 is year (YYYY-MM-DD)
    if (p1 > 1000) {
        const d = new Date(p1, p2 - 1, p3);
        if (!isNaN(d.getTime())) return d;
    }
  }

  const d = new Date(dateStr);
  return isNaN(d.getTime()) ? null : d;
};

// Generate a consistent ID based on content
const generateStableId = (record: Partial<StudentRecord>) => {
    // Ensure we use trimmed values for ID generation to prevent whitespace issues
    const str = `${record.tanggal}-${record.namaSiswa}-${record.uraianKategori}-${record.kelas}`;
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = (hash << 5) - hash + char;
        hash = hash & hash;
    }
    return `rec-${Math.abs(hash)}`;
};

// Retrieve local actions
const getLocalAction = (id: string) => {
    try {
        const stored = localStorage.getItem(`action_${id}`);
        return stored ? JSON.parse(stored) : null;
    } catch (e) {
        return null;
    }
};

// Get list of deleted IDs
const getDeletedIds = (): Set<string> => {
    try {
        const stored = localStorage.getItem('deleted_records');
        return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch (e) {
        return new Set();
    }
};

export const fetchStudentRecords = async (): Promise<StudentRecord[]> => {
  try {
    const response = await fetch(DATA_URL);
    const text = await response.text();
    
    const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
    if (lines.length < 2) return [];

    // Skip header line
    const dataLines = lines.slice(1);
    const deletedIds = getDeletedIds();

    const data: StudentRecord[] = dataLines.map((line) => {
      const values = parseCSVLine(line);
      
      // Strict mapping based on Spreadsheet Columns provided:
      // 0: Hari, 1: Tanggal, 2: Nama Siswa, 3: Kelas, 4: Kategori, 
      // 5: Uraian Kategori, 6: Keterangan, 7: Nama Guru, 8: Foto Siswa

      // We explicitly trim values here to ensure clean data and stable IDs
      const record: Partial<StudentRecord> = {
          hari: (values[0] || '').trim(),
          tanggal: (values[1] || '').trim(),
          namaSiswa: (values[2] || '').trim(),
          kelas: (values[3] || '').trim(),
          kategori: (values[4] || '').trim(),
          uraianKategori: (values[5] || '').trim(),
          keterangan: (values[6] || '').trim(),
          namaGuru: (values[7] || '').trim(),
          fotoSiswa: (values[8] || '').trim()
      };

      // Parse date object for filtering
      record.dateObj = parseDate(record.tanggal || '');

      // Generate ID
      const uniqueId = generateStableId(record);
      record.id = uniqueId;

      // Check if deleted locally
      record.isHidden = deletedIds.has(uniqueId);
      
      // Merge with Local Storage for Actions
      const localAction = getLocalAction(uniqueId);
      if (localAction) {
          record.statusTindakan = localAction.status;
          record.catatanTindakan = localAction.note;
          record.tindakan = localAction.status ? "Sudah Ditangani" : "Proses";
      } else {
          record.statusTindakan = false;
          record.tindakan = "Proses";
      }

      return record as StudentRecord;
    }).filter(r => r !== null) as StudentRecord[];

    return data;
  } catch (error) {
    console.error("Failed to fetch data", error);
    return [];
  }
};

export const saveActionLocally = (id: string, status: boolean, note: string) => {
    localStorage.setItem(`action_${id}`, JSON.stringify({ status, note }));
};

export const deleteRecordLocally = (id: string) => {
    const deletedIds = getDeletedIds();
    deletedIds.add(id);
    localStorage.setItem('deleted_records', JSON.stringify(Array.from(deletedIds)));
};

export const unhideRecordLocally = (id: string) => {
    const deletedIds = getDeletedIds();
    if (deletedIds.has(id)) {
        deletedIds.delete(id);
        localStorage.setItem('deleted_records', JSON.stringify(Array.from(deletedIds)));
    }
}

export const hideMultipleRecords = (ids: string[]) => {
    const deletedIds = getDeletedIds();
    ids.forEach(id => deletedIds.add(id));
    localStorage.setItem('deleted_records', JSON.stringify(Array.from(deletedIds)));
};

export const unhideMultipleRecords = (ids: string[]) => {
    const deletedIds = getDeletedIds();
    ids.forEach(id => deletedIds.delete(id));
    localStorage.setItem('deleted_records', JSON.stringify(Array.from(deletedIds)));
};
