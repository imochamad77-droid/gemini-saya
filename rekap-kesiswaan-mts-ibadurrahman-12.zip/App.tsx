
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Dashboard } from './components/Dashboard';
import { Infographics } from './components/Infographics';
import { AddRecord } from './components/AddRecord';
import { fetchStudentRecords } from './services/dataService';
import { StudentRecord, TabType } from './types';
import { LayoutDashboard, PieChart, PlusCircle } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [data, setData] = useState<StudentRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadData = async () => {
    setLoading(true);
    const records = await fetchStudentRecords();
    setData(records);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <div className="relative">
             <div className="w-16 h-16 border-4 border-slate-100 border-t-primary-500 rounded-full animate-spin"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-8 h-8 bg-primary-50 rounded-full animate-pulse"></div>
             </div>
          </div>
          <p className="mt-4 text-slate-400 font-medium animate-pulse tracking-wide">Memuat Data...</p>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard data={data} onRefresh={loadData} />;
      case 'infographics':
        return <Infographics data={data} />;
      case 'addRecord':
        // Pass callback to return to dashboard on cancel
        return <AddRecord onCancel={() => setActiveTab('dashboard')} />;
      default:
        return <Dashboard data={data} onRefresh={loadData} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-800">
      <Header />
      
      {/* Spacer for fixed header */}
      <div className="h-28 md:h-32 w-full"></div>

      <main className="flex-grow max-w-7xl mx-auto w-full px-4 md:px-6 py-4 relative z-10">
        
        {/* Modern Tab Navigation */}
        <div className="flex justify-center mb-10 no-print">
            <div className="bg-white/60 backdrop-blur-md p-1.5 rounded-full shadow-soft border border-white/50 inline-flex gap-2 relative">
                {[
                    { 
                        id: 'dashboard', 
                        label: 'Data Utama', 
                        icon: LayoutDashboard, 
                        activeClass: 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30',
                        inactiveClass: 'text-slate-500 hover:text-emerald-700 hover:bg-emerald-50'
                    },
                    { 
                        id: 'infographics', 
                        label: 'Infografis', 
                        icon: PieChart, 
                        activeClass: 'bg-blue-600 text-white shadow-lg shadow-blue-500/30',
                        inactiveClass: 'text-slate-500 hover:text-blue-700 hover:bg-blue-50'
                    },
                    { 
                        id: 'addRecord', 
                        label: 'Tambah Catatan', 
                        icon: PlusCircle, 
                        activeClass: 'bg-orange-500 text-white shadow-lg shadow-orange-500/30',
                        inactiveClass: 'text-slate-500 hover:text-orange-700 hover:bg-orange-50'
                    }
                ].map((tab) => {
                    const isActive = activeTab === tab.id;
                    const Icon = tab.icon;
                    return (
                        <button 
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as TabType)}
                            className={`
                                relative flex items-center gap-2 px-6 py-2.5 rounded-full transition-all duration-300 font-bold text-sm tracking-wide
                                ${isActive 
                                    ? `${tab.activeClass} scale-105 ring-1 ring-black/5` 
                                    : `bg-transparent ${tab.inactiveClass}`
                                }
                            `}
                        >
                            <Icon size={18} className={isActive ? 'text-white' : 'currentColor'} />
                            <span>{tab.label}</span>
                        </button>
                    )
                })}
            </div>
        </div>

        {/* Content Area with Animation */}
        <div className="min-h-[500px] animate-in slide-in-from-bottom-4 fade-in duration-500">
            {renderContent()}
        </div>

      </main>

      <Footer />
    </div>
  );
};

export default App;
