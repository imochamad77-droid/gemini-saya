
export interface StudentRecord {
  id: string; // Generated unique ID
  hari: string;
  tanggal: string; // Original string
  dateObj: Date | null; // Parsed date object
  namaSiswa: string;
  kelas: string;
  kategori: string; // e.g., Pelanggaran Ringan, Prestasi, etc.
  uraianKategori: string;
  keterangan: string;
  namaGuru: string;
  fotoSiswa: string;
  
  // Action fields (merged from localStorage or CSV)
  tindakan?: string; 
  statusTindakan?: boolean; // True if handled
  catatanTindakan?: string; // Additional notes
  
  // Visibility status
  isHidden?: boolean;
}

export type TabType = 'dashboard' | 'infographics' | 'addRecord';

export interface FilterState {
  startDate: string;
  endDate: string;
  searchName: string;
  kelas: string;
  kategori: string;
}

export const DATA_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQvEqE0_8blZ-17UcDZ96Q7FdkwD1VbRY18Vnx5AO6zb_yusrfWL2owCC7nzeL82PRep65p1-H6zdsM/pub?gid=1266400034&single=true&output=csv";
export const ADMIN_SHEET_URL = "https://docs.google.com/spreadsheets/d/1OnZA75CFs1NSpVfMl8t3h0QTo3bjfmrVR0L747wK8lI/edit?usp=sharing";

// Updated to use a direct Google Content CDN link which is more reliable for rendering
export const LOGO_URL = "https://lh3.googleusercontent.com/d/1-Oa5U4oJFZh8TFMja8Nq4g_EthG1TipO";
